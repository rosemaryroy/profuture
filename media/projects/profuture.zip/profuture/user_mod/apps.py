from django.apps import AppConfig


class UserModConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'user_mod'
